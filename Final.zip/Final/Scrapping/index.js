import puppeteer from 'puppeteer';
import mongoose from "mongoose";
const uri = "mongodb+srv://admin:admin@clusternode.qh7tm6h.mongodb.net/tirexo?retryWrites=true&w=majority";
import Movie from '../Interface/api/models/Movie.js'

(async () => {
    mongoose.connect(uri, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        })
        .then(() => {
            console.log('Mongo Initialized')
        })
        .catch((error) => {
            console.log('Mongo Failed: ', error)
        })
    const browser = await puppeteer.launch({headless : false});
    const page = await browser.newPage();
    await page.setDefaultNavigationTimeout(0);
    await page.goto('https://www.tirexo.al/films')
    const numberOfPage = await page.evaluate(() => {
        let numberPage = parseInt(document.querySelector('#dle-content > div.pagi-nav.clearfix.ignore-select > span.navigation > a:nth-child(12)').textContent)
        return numberPage
    })
    await page.close()
    let compteur
    let compteur2
    try {
        for (compteur = 0; compteur <= numberOfPage; compteur++) {
            const page2 = await browser.newPage()
            await page2.setDefaultNavigationTimeout(0);
            await page2.goto('https://www.tirexo.al/films/page/'+compteur)
            const filmPage = await page2.evaluate(() => {
                let filmPerPage = []
                // let filmOfPage = document.querySelectorAll('#dle-content > div> div.mov-i.img-box')
                let filmOfPage = document.querySelectorAll('#dle-content > div.mov.clearfix')
                for (let film of filmOfPage){
                    let originalTitle = film.querySelector('div.mov-i.img-box').getAttribute('data-original-title')
                    let link = film.querySelector('div.mov-i.img-box > a').href
                    let langue
                    try{
                        langue = (film.querySelector('span.langue').textContent).slice(2, -1)
                    }catch (err){
                        langue = ""
                    }
                    filmPerPage.push({
                        link: link,
                        originalTitle: originalTitle,
                        language: langue
                    })
                }
                return filmPerPage
            })
            await page2.close()
            compteur2 = 0
            for(let film of filmPage) {
                const finded = await Movie.findOne({originalTitle: film['originalTitle']})
                if (!finded) {
                    let linkMovie = film['link']
                    const page3 = await browser.newPage();
                    await page3.setDefaultNavigationTimeout(0);
                    await page3.goto(linkMovie, {waitUntil: "domcontentloaded"})
                    const infosMovies = await page3.evaluate(() => {
                        let testExist = document.querySelector('#dle-content > article')
                        if (testExist) {
                            let infos = []
                            let title = document.querySelector('#dle-content > article > div.cols-mov.clearfix.ignore-select > div > div:nth-child(1) > h1 > b').textContent.replaceAll('"', "'")
                            let year = document.querySelector('#dle-content > article > div.cols-mov.clearfix.ignore-select > div > div:nth-child(1) > h1 > span').textContent
                            let picture = document.querySelector('#dle-content > article > div.cols-mov.clearfix.ignore-select > div > div:nth-child(1) > img').src
                            let originalTitle = document.querySelector('#dle-content > article > div.cols-mov.clearfix.ignore-select > div > div:nth-child(1) > ul > li:nth-child(2) > div > span:nth-child(2) > span').textContent.replaceAll('"', "'")
                            let language = document.querySelector('#dle-content > article > div.cols-mov.clearfix.ignore-select > div > div:nth-child(1) > div > span.couleur-languesz').textContent
                            console.log(language)
                            let moreInfosLink = "Nothing"
                            let realisator = "Nothing"
                            let date = "Nothing"
                            let lisLi = document.querySelectorAll('#dle-content > article > div.cols-mov.clearfix.ignore-select > div > div:nth-child(1) > ul > li ')
                            for (let element of lisLi) {
                                let strong
                                try {
                                    strong = element.textContent
                                } catch (e) {
                                    strong = "Nothing"
                                }
                                if (strong.includes('Au cinéma')) {
                                    date = element.querySelector('span:nth-child(2)').textContent
                                }
                                if (strong.includes('Réalisateur(s)')) {
                                    realisator = document.querySelector('#realisateur').textContent.replaceAll('"', "'")
                                }
                                if (strong.includes("Plus d'information sur tmdb")) {
                                    moreInfosLink = element.querySelector('a').href
                                }
                            }
                            infos.push({
                                title: title,
                                year: year,
                                picture: picture,
                                originalTitle: originalTitle,
                                language: language,
                                realisator: realisator,
                                date: date,
                                moreInfosLink: moreInfosLink
                            })
                            return infos
                        }
                    })
                    if (infosMovies) {
                        let title = infosMovies[0]['title']
                        let year = infosMovies[0]['year']
                        if (year.includes('(')) {
                            while (year.includes('(')) {
                                year = year.toString().replace('(', "");
                            }
                        }
                        if (year.includes(')')) {
                            while (year.includes(')')) {
                                year = year.toString().replace(')', "");
                            }
                        }
                        year = parseFloat(year)
                        let date = infosMovies[0]['date']
                        let picture = infosMovies[0]['picture']
                        let originalTitle = infosMovies[0]['originalTitle']
                        let realisator = infosMovies[0]['realisator']
                        let language = (infosMovies[0]['language']).replace(" ", "")
                        let moreInfosLink = infosMovies[0]['moreInfosLink']
                        await page3.close()
                        const page4 = await browser.newPage();
                        await page4.setDefaultNavigationTimeout(0);
                        await page4.goto(moreInfosLink, {waitUntil: "domcontentloaded"})
                        const supplementaryInfosMovies = await page4.evaluate(() => {
                            let testExist = document.querySelector('#main > section > div.header.large.border.first > div > div')
                            if (testExist) {
                                let supplementaryInfos = []
                                let time
                                try {
                                    time = document.querySelector('span.runtime').textContent.trim()
                                } catch (e) {
                                    time = "Inconnu"
                                }
                                let likePercentage
                                try {
                                    likePercentage = document.querySelector('div.consensus.details > div > div').dataset.percent
                                }catch (e) {
                                    likePercentage = 0.0
                                }
                                let synopsis
                                try{
                                    synopsis = document.querySelector('div.header_info > div > p').innerText.replaceAll('"', "")
                                }catch (err){
                                    synopsis = ""
                                }
                                let listActors = document.querySelectorAll('#cast_scroller > ol > li.card')
                                let actors = []
                                if (listActors.length > 0) {
                                    for (let actor of listActors) {
                                        let actorName = actor.querySelector('p a').innerText.replaceAll('"', "'")
                                        actors.push(actorName)
                                    }
                                } else {
                                    actors = "Nothing"
                                }
                                let listGenders = document.querySelectorAll('span.genres > a')
                                let genders = []
                                if (listGenders.length > 0) {
                                    for (let gender of listGenders) {
                                        let genderName = gender.textContent
                                        genders.push(genderName)
                                    }
                                } else {
                                    genders = "Nothing"
                                }

                                let listTags = document.querySelectorAll('#media_v4 > div > div > div.grey_column > div > section > div:nth-child(1) > div > section.keywords.right_column > ul > li a')
                                let tags = []
                                if (listTags.length > 0) {
                                    for (let tag of listTags) {
                                        let tagsName = tag.textContent
                                        tags.push(tagsName)
                                    }
                                } else {
                                    tags = "Nothing"
                                }
                                supplementaryInfos.push({
                                    time: time,
                                    likePercentage: likePercentage,
                                    synopsis: synopsis,
                                    genders: genders,
                                    actors: actors,
                                    tags: tags,
                                })
                                return supplementaryInfos
                            }
                        })
                        await page4.close()
                        if (supplementaryInfosMovies) {
                            let time = supplementaryInfosMovies[0]['time']
                            let likePercentage = supplementaryInfosMovies[0]['likePercentage']
                            let synopsis = supplementaryInfosMovies[0]['synopsis']
                            let genders = supplementaryInfosMovies[0]['genders']
                            let actors = supplementaryInfosMovies[0]['actors']
                            let tags = supplementaryInfosMovies[0]['tags']
                            try {
                                const movie = await Movie.create({
                                    title,
                                    year,
                                    date,
                                    originalTitle,
                                    realisator,
                                    languages: language,
                                    genders,
                                    actors,
                                    tags,
                                    synopsis,
                                    time,
                                    picture,
                                    likePercentage
                                })
                            }catch (e) {
                                console.log("Page : "+compteur)
                                console.log("Element : "+compteur2)
                                console.log(e)
                            }
                        }
                    }
                }else{
                    const findLanguage = finded.languages
                    let verify = 0
                    for(var i= 0; i < findLanguage.length; i++){
                        if (findLanguage[i] === film['language']){
                            verify = 1
                        }
                    }
                    if(verify === 0){
                        const updatedFilm = await Movie.findByIdAndUpdate(finded._id, {languages: [...finded.languages, film['language']]}, {new: true})
                    }else{
                        continue
                    }
                }
            compteur2++
            }
        }
        console.log('yes')
    }catch (e) {
        console.log("Page : "+compteur)
        console.log("Element : "+compteur2)
        console.log(e)

    }
    await browser.close();
})
();

async function listDatabases(client){
    let databasesList = await client.db().admin().listDatabases();

    console.log("Databases:");
    databasesList.databases.forEach(db => console.log(` - ${db.name}`));
}

// function sleep(ms) {
//     return new Promise((resolve) => {
//         setTimeout(resolve, ms);
//     });
// }