import express from 'express'
import configure from './configurations/configuration.js'
const app = express();
const port = 8080;
app.use(express.json());

async function main () {
    const app = express()
    await configure(app)
    app.listen(process.env.PORT, (err) => {
      if (err) {
        console.log(err)
      } else {
        console.log(`Server Initialized ON ${port}`)
      }
    })
}

main()

// app.get('/movies', (req,res) => {
//     Movies.find().then((movies) => {
//         res.json(movies);
//     })
//     .catch((error) => {
//         console.log('Mongo Failed: ', error)
//     })
// })

// app.get('/movies/:title', (req, res) => {
//     Movies.findOne({title: req.params.title}).then((movies) => {
//         res.json(movies);
//     })
// })

// app.set('view engine', 'ejs');
//Routes
