import express from 'express'
const router = express.Router()
import Movies from "../models/movies"


router.get('/movies', (req,res) => {
    Movies.find().then((movies) => {
        res.json(movies);
    })
    .catch((error) => {
        console.log('Mongo Failed: ', error)
    })
})