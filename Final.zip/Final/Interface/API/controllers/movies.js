import Movies from "../models/movies"

export async function getAll (req, res) {
    
    const movies = await Movies.find()

    return res.json(movies)
  
}