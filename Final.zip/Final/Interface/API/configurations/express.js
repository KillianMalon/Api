import express from 'express'

/**
 * Express configuration.
 */
export async function configure (app) {
  app.use(express.static('public'))
  app.use(express.json())
  app.use(express.urlencoded({ extended: true }))
  
  console.log('Express Initialized.')
}